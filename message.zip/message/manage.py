#-*- encoding=UTF-8 -*-

from flask_script import Manager
from mybbs import db
from mybbs import create_app

app = create_app()
manager = Manager(app)

@manager.command
def init_database():
    db.drop_all()
    db.create_all()

if __name__ == '__main__':
    manager.run()
