#-*- encoding=UTF-8 -*-
from mybbs import create_app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
