# coding=utf-8
from mybbs.bbs import views
from flask import Blueprint
bbs_view = Blueprint('bbs_view', __name__)
