# coding=utf-8
from . import views
from flask import Blueprint
login_view = Blueprint('login_view', __name__)

