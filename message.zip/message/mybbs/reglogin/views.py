# coding=utf-8

from . import reglogin_view
from ..model import User, db
import hashlib
import random
from flask import render_template, redirect, request, flash, url_for
from flask_login import login_user, logout_user, login_required
from form import LoginForm, RegisterForm


@reglogin_view.route('/login/', methods={'get', 'post'})
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is not None:
            # 密码正确验证
            m = hashlib.md5()
            m.update(form.password.data + user.salt)
            print
            if m.hexdigest() != user.password:
                flash('密码输入错误')
                return redirect('/login')
            login_user(user)
            flash('登录成功')
            return redirect('/')
        else:
            flash('用户或密码错误')

    return render_template('login.html', form=form)


@reglogin_view.route('/register/', methods={'get', 'post'})
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST':
        if form.validate_on_submit():
            # 查看用户是否存在数据库中
            user = User.query.filter_by(username=form.username.data).first()
            if user is not None:
                flash('用户名已经存在')
                return redirect('/register')

            salt = ''.join(random.sample('0123456789abcdefghigklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', 10))
            m = hashlib.md5()
            m.update(form.password.data + salt)
            password = m.hexdigest()

            user = User(form.username.data, password, salt)
            # 数据库提交
            db.session.add(user)
            db.session.commit()
            flash('注册成功')
            return redirect(url_for('login_view.login'))

    return render_template('register.html', form=form)


@reglogin_view.route('/logout/')
@login_required
def logout():
    logout_user()
    flash('你已退出登录')
    return redirect(url_for('login_view.login'))
