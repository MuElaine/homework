# -*- encoding=UTF-8 -*-
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bootstrap import Bootstrap

app = None

db = SQLAlchemy(use_native_unicode='utf8')
bootstrap = Bootstrap()

login_manager = LoginManager()
login_manager.session_protection = 'strong'

login_manager.login_view = 'reglogin.login'

import sys

reload(sys)
sys.setdefaultencoding("utf-8")


def create_app():
    global app

    app = Flask(__name__, template_folder='templates')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqldb://root:123456@localhost:3306/db_bbs'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

    app.config['SECRET_KEY'] = 'MONKEY'

    db.init_app(app)
    bootstrap.init_app(app)
    login_manager.init_app(app)


    return app
